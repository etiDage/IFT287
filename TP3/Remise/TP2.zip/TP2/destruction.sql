---- Identification du schéma
SET search_path TO JardinCollectif;

-- Suppression des tables
DROP TABLE membres CASCADE;
DROP TABLE  lots CASCADE;
DROP TABLE  plante CASCADE;
DROP TABLE demandes CASCADE;
DROP TABLE assignation CASCADE;
DROP TABLE plants  CASCADE;