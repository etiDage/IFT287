---- Identification du schéma
SET search_path TO JardinCollectif;

-- affichage  des tables
SELECT *  FROM  membres;
SELECT *  FROM  lots;
SELECT *  FROM  plante;
SELECT *  FROM  demandes;
SELECT *  FROM  assignation;
SELECT *  FROM  plants;
